import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(FlashcardApp());

class Flashcard {
  String id;
  String question;
  String answer;
  Flashcard({required this.id, required this.question, required this.answer});
  Map<String, dynamic> toJson() => {'id': id, 'question': question, 'answer': answer};
  factory Flashcard.fromJson(Map<String, dynamic> j) =>
      Flashcard(id: j['id'], question: j['question'], answer: j['answer']);
}

class FlashcardApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flashcard Quiz',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: FlashcardHome(),
    );
  }
}

class FlashcardHome extends StatefulWidget {
  @override
  _FlashcardHomeState createState() => _FlashcardHomeState();
}

class _FlashcardHomeState extends State<FlashcardHome> {
  List<Flashcard> cards = [];
  int currentIndex = 0;
  bool showAnswer = false;
  late SharedPreferences prefs;
  final String storageKey = 'flashcards_v1';

  @override
  void initState() {
    super.initState();
    _loadCards();
  }
  Future<void> _loadCards() async {
    prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(storageKey);
    if (raw != null) {
      final list = jsonDecode(raw) as List<dynamic>;
      cards = list.map((e) => Flashcard.fromJson(e)).toList();
      if (cards.isEmpty) {
        cards = _defaultCards();
        await _saveCards();
      }
    } else {
      cards = _defaultCards();
      await _saveCards();
    }
    setState(() {});
  }

  Future<void> _saveCards() async {
    final raw = jsonEncode(cards.map((c) => c.toJson()).toList());
    await prefs.setString(storageKey, raw);
  }

  List<Flashcard> _defaultCards() {
    return [
      Flashcard(id: '1', question: 'What is Flutter?', answer: 'A UI toolkit by Google for building natively compiled apps for mobile, web, and desktop.'),
      Flashcard(id: '2', question: 'Dart is ___', answer: 'The programming language used to develop Flutter applications.'),
      Flashcard(id: '3', question: 'What is a Widget in Flutter?', answer: 'A basic building block of a Flutter UI. Everything in Flutter is a widget.'),
      Flashcard(id: '4', question: 'What is the root widget of every Flutter app?', answer: 'The MaterialApp or CupertinoApp widget.'),
      Flashcard(id: '5', question: 'What is Hot Reload in Flutter?', answer: 'A feature that allows you to see code changes instantly without restarting the app.'),
      Flashcard(id: '6', question: 'StatefulWidget vs StatelessWidget?', answer: 'StatefulWidget has a mutable state that can change over time, while StatelessWidget does not.'),
      Flashcard(id: '7', question: 'What is BuildContext in Flutter?', answer: 'It provides access to the widget tree and allows interaction with widget properties and themes.'),
      Flashcard(id: '8', question: 'What command creates a new Flutter project?', answer: 'flutter create project_name'),
      Flashcard(id: '9', question: 'What is the purpose of setState()?', answer: 'It notifies the framework that the internal state of a StatefulWidget has changed and needs rebuilding.'),
      Flashcard(id: '10', question: 'What is pubspec.yaml used for?', answer: 'It manages app metadata, dependencies, and assets in a Flutter project.'),
      Flashcard(id: '11', question: 'What is Flutter SDK?', answer: 'A collection of tools, libraries, and APIs used to build Flutter applications.'),
      Flashcard(id: '12', question: 'Can Flutter build web apps?', answer: 'Yes, Flutter can build apps for web, mobile, and desktop using the same codebase.'),
      Flashcard(id: '13', question: 'What is a Scaffold in Flutter?', answer: 'A layout structure that provides APIs for app bars, drawers, floating buttons, etc.'),
      Flashcard(id: '14', question: 'What is the default function that runs the Flutter app?', answer: 'void main() => runApp(MyApp());'),
      Flashcard(id: '15', question: 'What is a Future in Dart?', answer: 'A type that represents a value or error that will be available at some point in the future (asynchronous).'),
      Flashcard(id: '16', question: 'What is the difference between Hot Reload and Hot Restart?', answer: 'Hot Reload updates the UI without losing state, while Hot Restart resets the app and its state.'),
    ];
  }

  // 🔹 Reset cards to defaults
  Future<void> _resetCards() async {
    await prefs.remove(storageKey);
    cards = _defaultCards();
    await _saveCards();
    setState(() {
      currentIndex = 0;
      showAnswer = false;
    });
  }

  void _nextCard() {
    if (cards.isEmpty) return;
    setState(() {
      currentIndex = (currentIndex + 1) % cards.length;
      showAnswer = false;
    });
  }

  void _prevCard() {
    if (cards.isEmpty) return;
    setState(() {
      currentIndex = (currentIndex - 1 + cards.length) % cards.length;
      showAnswer = false;
    });
  }

  Future<void> _showAddEditDialog({Flashcard? editing}) async {
    final qCtrl = TextEditingController(text: editing?.question ?? '');
    final aCtrl = TextEditingController(text: editing?.answer ?? '');
    final isEditing = editing != null;

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(isEditing ? 'Edit Flashcard' : 'Add Flashcard'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(controller: qCtrl, decoration: const InputDecoration(labelText: 'Question')),
              TextField(controller: aCtrl, decoration: const InputDecoration(labelText: 'Answer')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final q = qCtrl.text.trim();
              final a = aCtrl.text.trim();
              if (q.isEmpty || a.isEmpty) return;
              setState(() {
                if (isEditing) {
                  editing!.question = q;
                  editing.answer = a;
                } else {
                  final id = DateTime.now().millisecondsSinceEpoch.toString();
                  cards.add(Flashcard(id: id, question: q, answer: a));
                  currentIndex = cards.length - 1;
                }
                _saveCards();
              });
              Navigator.pop(context);
            },
            child: Text(isEditing ? 'Save' : 'Add'),
          ),
        ],
      ),
    );
  }

  void _deleteCurrent() {
    if (cards.isEmpty) return;
    setState(() {
      cards.removeAt(currentIndex);
      currentIndex = (currentIndex > 0) ? currentIndex - 1 : 0;
      showAnswer = false;
      _saveCards();
    });
  }
  @override
  Widget build(BuildContext context) {
    final hasCards = cards.isNotEmpty;
    final current = hasCards ? cards[currentIndex] : null;

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFFB2EBF2), Color(0xFFE1F5FE)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text('Flashcard Quiz', style: TextStyle(color: Colors.white)),
          centerTitle: true,
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF42A5F5), Color(0xFF7E57C2)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          actions: [
            IconButton(icon: const Icon(Icons.refresh), tooltip: 'Reset', onPressed: _resetCards),
            IconButton(icon: const Icon(Icons.add), onPressed: () => _showAddEditDialog()),
            IconButton(icon: const Icon(Icons.edit), onPressed: hasCards ? () => _showAddEditDialog(editing: current) : null),
            IconButton(icon: const Icon(Icons.delete), onPressed: hasCards ? _deleteCurrent : null),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Text(
                hasCards ? '${currentIndex + 1} / ${cards.length}' : 'No cards',
                style: const TextStyle(fontSize: 18, color: Colors.black54),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: Center(
                  child: hasCards
                      ? AnimatedContainer(
                    duration: const Duration(milliseconds: 400),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      gradient: LinearGradient(
                        colors: showAnswer
                            ? [Colors.greenAccent.shade100, Colors.teal.shade200]
                            : [Colors.lightBlueAccent.shade100, Colors.indigoAccent.shade100],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 8, offset: Offset(2, 4))],
                    ),
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('Question', style: TextStyle(fontSize: 14, color: Colors.black54)),
                        const SizedBox(height: 10),
                        Text(current!.question, textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 30),
                        AnimatedCrossFade(
                          duration: const Duration(milliseconds: 400),
                          firstChild: const SizedBox.shrink(),
                          secondChild: Column(
                            children: [
                              const Divider(thickness: 1, color: Colors.white),
                              const SizedBox(height: 10),
                              const Text('Answer', style: TextStyle(fontSize: 14, color: Colors.black54)),
                              const SizedBox(height: 8),
                              Text(current.answer, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, color: Colors.white, fontWeight: FontWeight.w600)),
                            ],
                          ),
                          crossFadeState: showAnswer ? CrossFadeState.showSecond : CrossFadeState.showFirst,
                        ),
                        const SizedBox(height: 25),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: showAnswer ? Colors.purpleAccent : Colors.blueAccent,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                          ),
                          onPressed: () => setState(() => showAnswer = !showAnswer),
                          child: Text(showAnswer ? 'Hide Answer' : 'Show Answer'),
                        ),
                      ],
                    ),
                  )
                      : const Text('No flashcards yet. Tap + to add one.', style: TextStyle(fontSize: 18, color: Colors.black54)),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ElevatedButton.icon(
                    onPressed: hasCards ? _prevCard : null,
                    icon: const Icon(Icons.chevron_left),
                    label: const Text('Previous'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurpleAccent,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: hasCards ? _nextCard : null,
                    icon: const Icon(Icons.chevron_right),
                    label: const Text('Next'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurpleAccent,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
